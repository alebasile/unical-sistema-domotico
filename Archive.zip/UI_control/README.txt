In questo programma LabVIEW si esegue l'algoritmo di gestione degli elettrodomestici.

Ogni minuto viene letto il valore di potenza elaborato da Arduino e inviato tramite XBee.

Sulla base di queste e sulle interazioni con l'interfaccia si può testare il funzionamento dell'algoritmo.