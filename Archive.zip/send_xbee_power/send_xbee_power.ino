#define N 1000 
#define CALIBRATION 0.003
#define TURNS 2000
#define R 100
#define V 230

float sensorValue, sum, vRms, iRms;
int P;
int sumP = 0, cont = 0;
byte byte1, byte2, checksum;
//Creo il frame da inviare rispettando la struttura API Transmitt Request 0x10
byte Frame[20] =  {0x7E,0x00,0x10,0x10,0x00,0x00,0x13,0xA2,0x00,0x41,0x99,0x61,0xF1,0xFF,0xFE,0x00,0x00,0x00,0x00,0x00}; 

void setup() {
  Serial.begin(9600);
  Serial1.begin(9600);
  pinMode(A0,INPUT);
}

void loop() {
  //Calcolo il valore RMS della tensione misurata con il sensore  
  sum = 0;
  for(int i=0;i<N;i++){ 
    sensorValue = (analogRead(A0)*(3.3/1023.0)) - 1.65;
    sum += (sensorValue*sensorValue); 
    delay(5);
  }
  vRms = sqrt(sum/N) - CALIBRATION;
  //Calcolo il valore RMS della corrente
  iRms = vRms * (TURNS/R);
  //Calcolo la potenza
  P = V * iRms;
  sumP += P;
  
  //Aspetto per fare la media dei valori ottenuti
  if(cont<=12){
    cont +=1;    
  }
  else{
    P = sumP/12;
    cont = 0;
    sumP = 0;

    //Converto il valore in due byte
    byte1 = P >> 8;
    byte2 = P & 0xFF;

    //Calcolo il checksum del frame
    checksum = 0xFF - ((0x4EE + byte1 + byte2) & 0xFF);

    //Aggiungo al frame i byte appena calcolati
    Frame[17] = byte1;
    Frame[18] = byte2;
    Frame[19] = checksum;

    //Invio il frame tramite la seriale  
    Serial1.write(Frame,20);
  }
  delay(10); 
}
