In questo programma LabVIEW si esegue una simulazione dell'algoritmo di gestione degli elettrodomestici ipotizzando di testarlo per una giornata divisa in slot da 5 minuti. 

I dati provenienti dal sensore vengono sostituiti dal profilo realizzato su Excel.